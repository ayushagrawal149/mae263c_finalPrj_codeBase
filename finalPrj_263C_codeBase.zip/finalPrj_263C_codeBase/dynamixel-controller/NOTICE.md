This product includes software developed at
Robotis Inc. (http://www.robotis.us/) 
under the Apache version 2.0 license
from https://github.com/ROBOTIS-GIT/DynamixelSDK
