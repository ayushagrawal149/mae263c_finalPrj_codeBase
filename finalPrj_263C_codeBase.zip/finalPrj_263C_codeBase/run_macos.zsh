#!/bin/zsh

source venv/bin/activate;
python3 $(pwd)/jsid_Control_finalProject.py;